function [Z] = xnor(A,B)
%XNOR Summary of this function goes here
%   Detailed explanation goes here
Z = not(xor(A,B));
end

