function Z = nor(Z1,Z2)

Z = not(or(Z1,Z2));
end

%------------- END OF CODE --------------