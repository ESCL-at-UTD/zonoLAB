function [C] = nandLogic(A,B)
%NOR Summary of this function goes here
%   Detailed explanation goes here
C = ~(A&B); 
end

