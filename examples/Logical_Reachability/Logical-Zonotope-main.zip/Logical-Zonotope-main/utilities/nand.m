function [Z] = nand(A,B)
%NAND Summary of this function goes here
%   Detailed explanation goes here
Z = not(and(A,B));
end

